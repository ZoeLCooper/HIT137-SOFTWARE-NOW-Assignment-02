def separate_and_convert(input_str):
    even_numbers = [ord(char) for char in input_str if char.isdigit() and int(char) % 2 == 0]
    ascii_letters = [ord(char) for char in input_str if char.isupper()]
    
    return ''.join(map(str, even_numbers)), ''.join(map(str, ascii_letters))

input_str = '56aAww1984sktr235270aYmn145ss785fsq31D0'
result_numbers, result_letters = separate_and_convert(input_str)

print(f'Number String: {result_numbers}')
print(f'Letter String: {result_letters}')
