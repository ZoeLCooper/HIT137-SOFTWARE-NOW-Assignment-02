# Initialize total
total = 0

# Nested loops to update total
for i in range(5):
    for j in range(3):
        if i + j == 5:
            total += i + j
        else:
            total -= (i - j)

# Initialize counter
Counter = 0

# Adjust total to be 13
while Counter < 5:
    if total < 13:
        total += 1
    elif total > 13:
        total -= 1
    else:
        Counter += 2

# Print the final result
print("Final total:", total)
